Motion / Movemint — static deploy
====================================

Files:
- index.html  (Solana + Phantom + Jupiter quotes/swaps)
- evm.html    (Ethereum & Base + 0x quotes/swaps, 0.05% fee to 0x3961…C38f)

How to use:
1) Upload BOTH files to your GitHub repo root (or any static host).
2) If replacing existing placeholders on GitHub:
   - Upload these two and choose “Replace” to overwrite.
3) Open:
   - /index.html  → Solana
   - /evm.html    → Ethereum & Base
